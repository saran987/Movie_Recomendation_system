import random
from re import A
import string
from webbrowser import get
import pandas as pd
import ast 
from ast import literal_eval
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity, linear_kernel
#!pip install pyttsx3
import pyttsx3

Introduce_Ans = [" "]
GREETING_INPUTS = ("hello", "hi", "hiii", "hii", "hiiii", "hiiii", "greetings", "sup", "what's up", "hey", 'Hi', 'HI')
GREETING_RESPONSES = ["Hi, Would you like some movie recommendations?(Y/N)", "Hey, Like some movie recommendations?(Y/N)"]
Basic_Q = ["yes", "y", 'Y', 'YES']
Basic_Ans = "Provide a movie to find its similar movies"
Basic_Om = ["no", "n", 'N', 'No', 'thanks', 'thank you','Thanks', 'Thank You']
Basic_AnsM = "You are Welcome! Have a great day!"

a = random.choice(GREETING_RESPONSES)
def convert_int(x):
    try:
        return int(x)
    except:
        return np.nan

md = pd.read_csv(r'C:\UMBC files\Data690_NLP\Movie Recommendation Bot\making chatbot nlp\movies_metadata.csv')
links_small = pd.read_csv(r'C:\UMBC files\Data690_NLP\Movie Recommendation Bot\making chatbot nlp\links_small.csv')
md['tagline'] = md['tagline'].fillna('')
md['description'] = md['overview'] + md['tagline']
md['description'] = md['description'].fillna('')
tf = TfidfVectorizer(analyzer='word',ngram_range=(1, 2),min_df=0, stop_words='english')
tfidf_matrix = tf.fit_transform(md['description'])
cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)
md = md.reset_index()
titles = md['title']
indices = pd.Series(md.index, index=md['title'])

def get_recommendations(title):
    idx = indices[title]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:10]
    movie_indices = [i[0] for i in sim_scores]
    return titles.iloc[movie_indices]



def chat(user_response):
    global resp
    flag = True
    found = 0
    engine = pyttsx3.init()
    engine.setProperty('volume',1.0)
    engine.say(user_response)
    engine.runAndWait()
    engine.stop()
    if (user_response in GREETING_INPUTS):    
        return a
    elif (user_response in Basic_Q):
        return Basic_Ans
    elif ((user_response not in GREETING_INPUTS) and (user_response not in Basic_Q) and (user_response not in Basic_Om)):
        for i in range(len(md['original_title'])):
            if md['original_title'][i] == user_response:
                found = 1
                print(found) 
        if found == 1:
            print(str(get_recommendations(user_response)))
            final_list = ''
            p = get_recommendations(user_response)
            for i in p:
                final_list = final_list + str(i) + '<br>'
            return final_list

        else:
            return 'I dont understand would you like to try again(Y/N)' 
    elif (user_response in Basic_Om):
        return Basic_AnsM